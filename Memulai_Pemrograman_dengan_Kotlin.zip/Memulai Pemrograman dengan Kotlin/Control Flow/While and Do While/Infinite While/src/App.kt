// main function
fun main() {
    var value = 'A'
    do {

        print(value)
        value++
    } while (value <= 'Z')
}